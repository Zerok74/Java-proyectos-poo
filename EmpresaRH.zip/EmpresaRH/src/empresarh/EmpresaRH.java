package empresarh;

import java.util.Scanner;

public class EmpresaRH {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Departamento depa = new Departamento("001", "TI");
        int opcion =0;
        
        do{
            System.out.println("Menu gestion departamento");
            System.out.println("1.- Mostrar empleados");
            System.out.println("2.- Calcular costo departamento");
            System.out.println("3.- Agregar nuevo empleado");
            System.out.println("4.- Simular bonus a empleado");
            System.out.println("5.- Salir");
            opcion = input.nextInt();
            
            if(opcion == 1){
                
                depa.mostrarTodosLosEmpleados();
                
            }else if(opcion ==2){
            
                System.out.println("Costo total departamento : $"+depa.calcularTotalSalarios());
                
            }else if(opcion ==3){
                System.out.println("Que tipo de empleado desea ingresar...");
                System.out.println("1.- Empleado por horas 2.-Empleado asalariado");
                int tipoEmpleado = input.nextInt();
                
                if (tipoEmpleado ==1) {
                    
                    System.out.println("Ingrese el nombre : ");
                    String nombre = input.next();
                    
                    System.out.println("ID");
                    String id = input.next();
                    
                    System.out.println("Cantidad de horas : ");
                    double cantHoras = input.nextDouble();
                    
                    System.out.println("Valor hora : ");
                    double valorHora = input.nextDouble();
                    
                    EmpleadoPorHora emple = new EmpleadoPorHora(cantHoras, valorHora, id, nombre);
                    
                    depa.agregarEmpleado(emple);
                    
                }else if(tipoEmpleado ==2){
                
                    System.out.println("Ingrese el nombre : ");
                    String nombre = input.next();
                    
                    System.out.println("ID");
                    String id = input.next();
                    
                    System.out.println("Sueldo base : ");
                    double sueldo = input.nextDouble();
                    
                    EmpleadoAsalariado emple = new EmpleadoAsalariado(id, nombre, sueldo);
                    
                    depa.agregarEmpleado(emple);

                }
 
            }else if (opcion ==4){
                
                System.out.println("Ingrese el id de un empleado ... ");
                String id = input.next();
                
                depa.buscarPorIdParaSimularBonus(id);
            
            }else if(opcion ==5){
                System.out.println("Saliendo del sistema");
            }else{
                System.out.println("Ingrese una opcion valida");
            }
        
        }while(opcion != 5);
        

    }
    
}
