package empresarh;

public interface BonusCalculable {

    double calcularBonus();

}
