package empresarh;

public class EmpleadoAsalariado extends Empleado implements BonusCalculable {

    public EmpleadoAsalariado(String idEmpleado, String nombre, double sueldoBase) {
        super(idEmpleado, nombre, sueldoBase);
    }
    
    @Override
    public double calcularSalario() {
        return sueldoBase;
    }

    @Override
    public double calcularBonus() {
        return sueldoBase * 1.12;
    }

    @Override
    public void mostrarDatos() {
        System.out.println("\nNombre : "+nombre);
        System.out.println("Id : "+idEmpleado);
        System.out.println("Tipo empleado : Asalariado");
        System.out.println("Sueldo : $"+calcularSalario()+"\n");
    }
   
    
    
    
    
    
}
