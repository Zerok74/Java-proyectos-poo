package empresarh;

public class EmpleadoPorHora extends Empleado implements BonusCalculable {

    private double cantHoras;
    private double valorHora;

    public EmpleadoPorHora(double cantHoras, double valorHora, String idEmpleado, String nombre) {
        super(idEmpleado, nombre, 0);
        this.cantHoras = cantHoras;
        this.valorHora = valorHora;
    }
    
    @Override
    public double calcularSalario() {
        double sueldo = cantHoras * valorHora;
        return sueldo;
    }

    @Override
    public double calcularBonus() {
        
        if (cantHoras > 35) {
            System.out.println("El empleado cumple con las horas minimas para el bonus");
            return calcularSalario() * 1.07;
        
        } else {
            System.out.println("El empleado no cumple con el minimo de horas para optar al bonus");
            return calcularSalario();
        }

    }

    @Override
    public void mostrarDatos() {
        System.out.println("\nNombre : "+nombre);
        System.out.println("Id : "+idEmpleado);
        System.out.println("Tipo empleado : Por horas");
        System.out.println("Valor hora : $"+valorHora);
        System.out.println("Cantidad de horas : "+cantHoras);
        System.out.println("Sueldo : $"+calcularSalario()+"\n");
    }

    


    
}
