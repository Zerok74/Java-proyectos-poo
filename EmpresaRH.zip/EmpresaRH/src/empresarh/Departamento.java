package empresarh;

import java.util.ArrayList;
import java.util.List;

public class Departamento {
    
    private String idDepartamento;
    private String nombre;
    private List<Empleado> empleados;

    public Departamento() {
    }

    public Departamento(String idDepartamento, String nombre) {
        this.idDepartamento = idDepartamento;
        this.nombre = nombre;
        this.empleados = new ArrayList<>();
    }
    
    public void agregarEmpleado(Empleado emple){
        
        empleados.add(emple);
        System.out.println("Empleado agregado con exito");
    }
    
    public double calcularTotalSalarios(){
        double total =0;
        for(Empleado emple : empleados){
            total = total + emple.calcularSalario();
        }
        return total;
    }
    
    public void buscarPorIdParaSimularBonus(String idBuscado){
        for (Empleado emple : empleados){
            if (emple.getIdEmpleado().equals(idBuscado)) {
                System.out.println("Empleado encontrado : ");
                System.out.println("$" + emple.calcularBonus() );
            }
        }
    }
    
    public void mostrarTodosLosEmpleados(){
        for (Empleado emple : empleados) {
            emple.mostrarDatos();
        }
    }
    
    
    
}
