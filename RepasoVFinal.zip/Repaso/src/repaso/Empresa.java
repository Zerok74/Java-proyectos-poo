package repaso;

import java.util.ArrayList;
import java.util.List;

public class Empresa {
    
    private List<Empleado> listaEmpleados;

    public Empresa() {
        this.listaEmpleados = new ArrayList<>();
    }
    
    
}
