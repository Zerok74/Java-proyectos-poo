package proyectorapi;


public class VentaEstampillas implements IServicio{
    
    private double precioUnitario =900;
    private double cantidad;

    public VentaEstampillas(double cantidad) {
        this.cantidad = cantidad;
    }
    
    @Override
    public double calcularTotalAPagar(){
        double totalAPagar = (precioUnitario * cantidad) * 1.19;
        return totalAPagar;
    }
    
    @Override
    public void impimirBoleta(){
        System.out.println("\nBOLETA");
        System.out.println("Venta de estampillas");
        System.out.println("Precio unitario : $"+ precioUnitario);
        System.out.println("Cantidad : "+cantidad);
        System.out.println("Total : "+ calcularTotalAPagar()+ "\n");
    }

    
}
