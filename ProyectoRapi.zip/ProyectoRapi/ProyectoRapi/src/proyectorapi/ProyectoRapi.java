package proyectorapi;

import java.util.Scanner;

public class ProyectoRapi {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int opcion =0;
        
        do{
            System.out.println("1.- calcular envio nacional ");
            System.out.println("2.- calcular envio internacional ");
            System.out.println("3.- venta estampillas");
            System.out.println("4.- salir");
            opcion = input.nextInt();
            
            if (opcion ==1) {
                System.out.println("Envio Nacional");
                
                System.out.println("Codigo : ");
                String codigo = input.next();
                
                System.out.println("Region destino : ");
                String region = input.next();
                
                System.out.println("Peso : ");
                double peso = input.nextDouble();
            
                Nacional envio = new Nacional (region, codigo, peso);
                envio.impimirBoleta();
            
            }else if(opcion == 2){
                System.out.println("Envio Internacional ");
                
                System.out.println("pais destino");
                String pais = input.next();
                
                System.out.println("tasa impuesto");
                double tasa = input.nextDouble();
                
                System.out.println("codigo");
                String codigo = input.next();
                
                System.out.println("peso");
                double peso = input.nextDouble();
                
                Internacional envio = new Internacional(pais, tasa, codigo, peso);
                envio.impimirBoleta();
                
                
            }else if(opcion ==3){
                System.out.println("Venta estampillas");
                System.out.println("Ingrese la cantidad");
                double cantidad = input.nextDouble();
                
                VentaEstampillas venta = new VentaEstampillas(cantidad);
                venta.impimirBoleta();
            } else if (opcion == 4){
                System.out.println("Saliendo del sistema");
            }else {
                System.out.println("Ingrese una opcion valida");
            
            }

        }while (opcion !=4);



    }
    
}
