package proyectorapi;

public interface IServicio {
    
    double calcularTotalAPagar();
    
    void impimirBoleta();
    

}
