/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectorapi;

/**
 *
 * @author SSDD
 */
public abstract class Envio {
    
    protected String codigo;
    protected double peso;
    protected final double tarifaBase = 2000;

    public Envio(String codigo, double peso) {
        this.codigo = codigo;
        this.peso = peso;
    }

    public Envio() {
    }
    
    public abstract double calcularValorEnvio();
    
    
}
