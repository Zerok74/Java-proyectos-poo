package proyectorapi;

public class Internacional extends Envio implements IServicio{

    private String paisDestino;
    private double tasaImpuesto;

    public Internacional(String paisDestino, double tasaImpuesto, String codigo, double peso) {
        super(codigo, peso);
        this.paisDestino = paisDestino;
        this.tasaImpuesto = tasaImpuesto;
    }
    
    @Override
    public double calcularValorEnvio(){
        double valorEnvio = tarifaBase + (peso * 1500);
        double impuesto = valorEnvio * tasaImpuesto /100;
        valorEnvio = valorEnvio + impuesto;
        return valorEnvio;
    }
    
    @Override
    public double calcularTotalAPagar(){
        double total = calcularValorEnvio() * 1.19;
        return total;
    }
    
    @Override
    public void impimirBoleta(){
        System.out.println("\nBOLETA");
        System.out.println("Envio internacional");
        System.out.println("Codigo : "+codigo);
        System.out.println("Peso : "+peso+"kg");
        System.out.println("Pais destino : "+paisDestino);
        System.out.println("Tasa Impuesto pais de destino : "+ tasaImpuesto+"%");
        System.out.println("Costo envio : " + calcularValorEnvio());
        System.out.println("IVA : 19%");
        System.out.println("Total a pagar : " + calcularTotalAPagar()+"\n");
    }

    
}
