package proyectorapi;

public class Nacional extends Envio implements IServicio{
    
    private String regionDestino;

    public Nacional(String regionDestino, String codigo, double peso) {
        super(codigo, peso);
        this.regionDestino = regionDestino;
    }
    
    @Override
    public double calcularValorEnvio(){
        double valorEnvio = tarifaBase + (peso * 500);
        return valorEnvio;
        
    }

    @Override
    public double calcularTotalAPagar() {
        double totalAPagar = calcularValorEnvio() * 1.19;
        return totalAPagar;
    }

    @Override
    public void impimirBoleta() {
        System.out.println("Boleta");
        System.out.println("Envio Nacional");
        System.out.println("Region destino : "+regionDestino);
        System.out.println("Peso envio : "+peso+"kg");
        System.out.println("Codigo envio : "+ codigo);
        System.out.println("Valor envio : $" + calcularValorEnvio());
        System.out.println("IVA : 19%");
        System.out.println("Total a pagar : $" + calcularTotalAPagar());
    
    }
    
}
