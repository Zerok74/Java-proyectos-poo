package tienda;

public class Libro extends Producto{
    
    private String autor;
    private int cantPaginas;

    public Libro(String autor, int cantPaginas, String idProducto, String nombre, double precio) {
        super(idProducto, nombre, precio);
        this.autor = autor;
        this.cantPaginas = cantPaginas;
    }
    
    public boolean esLecturaLiviana(){
        return cantPaginas < 300;
    }
    
    @Override
    public double calcularEnvio() {
        if (esLecturaLiviana()){
            return 0;
        }else{
            return 1500;
        }
    }
    
    @Override
    public void mostrarDatos() {
        System.out.println("Nombre : "+nombre);
        System.out.println("ID : "+idProducto);
        System.out.println("Precio : $"+precio);
        System.out.println("Autor : "+autor);
        System.out.println("Cantidad de paginas : "+cantPaginas+"\n");
    }
    
}
