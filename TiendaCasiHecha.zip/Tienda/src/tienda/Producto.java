package tienda;

public abstract class Producto {
    
    String idProducto;
    String nombre;
    double precio;

    public Producto() {
    }
    
    public Producto(String idProducto, String nombre, double precio) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.precio = precio;
    }
    
    public abstract void mostrarDatos();
    
    public abstract double calcularEnvio();
    
    public double calcularDescuento(double descuento){
        return precio - (precio*descuento/100);   
    }

    public String getIdProducto() {
        return idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }
    
    

    
}
