package tienda;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Tienda {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Electronico elec1 = new Electronico("Samsung", 32, "001", "Celular A20", 68990);
        Electronico elec2 = new Electronico("Samsung", 12, "002", "Microondas", 45990);
        Ropa prenda1 = new Ropa("M", "Rojo", "003", "Camiseta Chile", 45990);
        Ropa prenda2 = new Ropa("L", "Verde", "004", "Camiseta Wanderers", 42990);
        Libro libro1 = new Libro("Leon Tolstoi", 900, "005", "Ana Karenina", 22000);
        Libro libro2 = new Libro("Marcela Paz", 90, "006", "Papelucho y el Marciano", 15000);

        List<Producto> productosDisponibles = new ArrayList<>();

        productosDisponibles.add(elec1);
        productosDisponibles.add(elec2);
        productosDisponibles.add(prenda1);
        productosDisponibles.add(prenda2);
        productosDisponibles.add(libro1);
        productosDisponibles.add(libro2);
        int opcion = 0;

        do {
            System.out.println("MENU");
            System.out.println("1.- Nuevo Cliente");
            System.out.println("2.- Salir");
            opcion = input.nextInt();

            if (opcion == 1) {
                System.out.println("Ingrese el nombre del Cliente: ");
                String nombre = input.next();

                System.out.println("Inrgese el Id del cliente : ");
                String id = input.next();

                Cliente cliente = new Cliente(id, nombre);
                Pedido pedido = new Pedido();
                
                int opcionM2=0;
                do {
                    System.out.println("Hola " + cliente.getNombre());
                    System.out.println("1.- Ver productos Disponibles");
                    System.out.println("2.- Comprar");

                    opcionM2 = input.nextInt();

                    if (opcionM2 == 1) {
                        System.out.println("Productos Disponibles : \n");

                        for (int i = 0; i < productosDisponibles.size(); i++) {
                            System.out.println("Producto " + i);
                            productosDisponibles.get(i).mostrarDatos();
                        }

                    } else if (opcionM2 == 2) {
                        int volverAComprar = 0;
                        do {
                            // recorremos la lista de productos disponibles
                            System.out.println("Productos Disponibles : \n");
                            
                            for (int i = 0; i < productosDisponibles.size(); i++) {
                                System.out.println("Producto " + i);
                                productosDisponibles.get(i).mostrarDatos();
                            }
                            
                            // el cliente ingresa el indice del producto que quiere agregar al pedido
                            System.out.println("Indique el numero del producto que desea agregar al pedido");
                            int nroProducto = input.nextInt();
                            
                            // segun el indice que ingreso el cliente creamos el producto a comprar
                            Producto productoComprar = productosDisponibles.get(nroProducto);
                            
                            // agregamos el producto a comprar al pedido
                            pedido.agregarProducto(productoComprar);

                            System.out.println("Desea agregar otro prodcuto al pedido)\n 1.-Si 2.- No");
                            volverAComprar = input.nextInt();
                        
                        
                        } while (volverAComprar != 2);
                     
                    }else if(opcionM2 == 3){
                        System.out.println("PEDIDO ACTUAL");
                       
                        // esta parte la hacen ustedes mostrando el pedido
                        // deben calcular el total del pedido
                        // mostrar los productos del pedido
                        // mostrar el costo del envio
                        // buen fin de semana :)
                        
                    }else if (opcionM2 == 4){
                        System.out.println("FInalizar pedido");
                        cliente.realizarPedido(pedido);
                    
                    }else if(opcionM2 == 5){
                    
                        System.out.println("Saliendo");
                    }else {
                        System.out.println("Ingrese una opcion valida");
                    }

                } while (opcionM2!=5);

            } else if (opcion == 2) {
                System.out.println("Saliendo");
            } else {
                System.out.println("Ingresa una opcion valida");
            }

        } while (opcion != 2);

    }

}
