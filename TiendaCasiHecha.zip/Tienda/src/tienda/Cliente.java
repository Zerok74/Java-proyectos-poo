package tienda;

import java.util.ArrayList;

public class Cliente {
    
    private String id;
    private String nombre;
    private ArrayList<Pedido> pedidosRealizados;

    public Cliente(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        pedidosRealizados = new ArrayList<>();
    }

    public void realizarPedido(Pedido pedido){
        pedidosRealizados.add(pedido);
    }

    public String getNombre() {
        return nombre;
    }
        
}
