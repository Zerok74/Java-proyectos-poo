package tienda;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
    
    private List<Producto> listaProductos;
    private double total;

    public Pedido() {
        listaProductos = new ArrayList<>();
        total = 0;
    }
    
    public void agregarProducto(Producto pro){
        listaProductos.add(pro);
    }
    
    public double calcularTotal(){
        total = 0;
        for(Producto producto : listaProductos){
            total = total +producto.getPrecio();
        }
        return total;
    }
    
    
    
}
