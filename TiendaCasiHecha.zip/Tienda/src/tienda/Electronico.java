package tienda;

public class Electronico extends Producto {

    private String marca;
    private int garantiaMeses;

    public Electronico() {
    }
    
    public Electronico(String marca, int garantiaMeses, String idProducto, String nombre, double precio) {
        super(idProducto, nombre, precio);
        this.marca = marca;
        this.garantiaMeses = garantiaMeses;
    }
    
    public void extenderGarantia(int mesesExtra){
        garantiaMeses = garantiaMeses+mesesExtra;
    }
    
    @Override
    public double calcularEnvio(){
        double precioEnvio = precio * 0.08;
        return precioEnvio;
    }
    
    @Override
    public void mostrarDatos() {
        System.out.println("Nombre : "+nombre);
        System.out.println("ID : "+idProducto);
        System.out.println("Precio : $"+precio);
        System.out.println("Marca : "+marca);
        System.out.println("Garantia : "+garantiaMeses+" meses\n");
    }
}
