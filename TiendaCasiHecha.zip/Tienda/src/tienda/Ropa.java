package tienda;

public class Ropa extends Producto{
    
    private String talla;
    private String color;

    public Ropa(String talla, String color, String idProducto, String nombre, double precio) {
        super(idProducto, nombre, precio);
        this.talla = talla;
        this.color = color;
    }

    public Ropa() {
    }
    
    public void ajustarTalla(String tallaNueva){
        talla = tallaNueva;
    }

    @Override
    public double calcularEnvio() {
        return 1200;
    }

    @Override
    public void mostrarDatos() {
        System.out.println("Nombre : "+nombre);
        System.out.println("ID : "+idProducto);
        System.out.println("Precio : $"+precio);
        System.out.println("Talla : "+talla);
        System.out.println("Color : "+color+"\n");
    }
    
    

    
}
